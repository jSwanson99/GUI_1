$(function() {
    $("#three").removeClass('hot');
    $("li.hot").addClass('favorite');
});